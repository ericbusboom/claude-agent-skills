# Docker Compose Patterns: League Node Template

This document covers the Docker Compose structure for the docker-node-template stack,
how the three run modes work, service definitions, networking, and volume patterns.

---

## Service Architecture

The full stack has these services:

```
postgres        PostgreSQL 16 Alpine — the database
app             Express + TypeScript backend (Node 20)
client          Vite dev server (React + TypeScript)
caddy           Caddy reverse proxy — routes traffic, handles SSL
```

In different run modes, some services run outside Docker:

| Service | Local Native | Full Docker | Hybrid/Remote DB |
|---|---|---|---|
| postgres | In Docker | In Docker | Digital Ocean (not local) |
| app | Native (host) | In Docker | Native or Docker |
| client | Native (host) | In Docker | Native or Docker |
| caddy | Not used in dev | In Docker | In Docker or not |

---

## Core Compose Concepts in This Stack

### Service-to-service networking

Inside Docker Compose, services reach each other by **service name**, not `localhost`.

```yaml
# WRONG: app connecting to postgres via localhost
DATABASE_URL=postgresql://user:pass@localhost:5432/db

# RIGHT: app connecting to postgres via service name
DATABASE_URL=postgresql://user:pass@postgres:5432/db
```

This is the single most common misconfiguration. If the app is in Docker and says
"connection refused to localhost:5432", the database URL is using localhost instead of
the service name.

### Health checks

The postgres service should have a health check so dependent services wait for it to be
ready before starting:

```yaml
services:
  postgres:
    image: postgres:16-alpine
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER}"]
      interval: 5s
      timeout: 5s
      retries: 5

  app:
    depends_on:
      postgres:
        condition: service_healthy
```

Without `condition: service_healthy`, the app may start before Postgres accepts connections,
causing a crash-loop. If the app keeps restarting, this is worth checking.

### Volume patterns

Two main volume types in this stack:

**Named volumes** (for Postgres data persistence):
```yaml
volumes:
  postgres_data:

services:
  postgres:
    volumes:
      - postgres_data:/var/lib/postgresql/data
```

**Bind mounts** (for hot reload in development):
```yaml
services:
  app:
    volumes:
      - ./server:/app/server       # source code
      - /app/node_modules          # prevent overwriting container's node_modules
```

The anonymous mount for `node_modules` is critical — without it, the host's `node_modules`
(which may not match the container's OS/arch) overwrites the container's correctly-built modules.

---

## Environment Variables and Secrets

Env vars flow through in two ways:

**1. `.env` file for local development:**
```bash
# docker-compose.yml references an env file
env_file:
  - secrets/.env.decrypted  # or .env
```

**2. `entrypoint.sh` for runtime secrets:**
The `docker/entrypoint.sh` script runs before the app starts and:
- Reads SOPS-encrypted secrets if a key is available
- Exports env vars from decrypted files
- Runs `prisma migrate deploy`
- Then execs the main process

If secrets aren't loading, check:
```bash
docker compose exec app env | grep DATABASE_URL
docker compose logs app | head -20  # look for entrypoint errors
```

---

## Common Compose Commands

```bash
# Start all services (detached)
docker compose up -d

# Start all services with build (after code changes to Dockerfiles)
docker compose up -d --build

# Start specific services only
docker compose up -d postgres
docker compose up -d postgres app

# View status
docker compose ps

# View logs (follow)
docker compose logs -f
docker compose logs -f app
docker compose logs -f postgres

# Execute a command in a running container
docker compose exec app sh
docker compose exec postgres psql -U postgres

# Stop everything (keeps volumes)
docker compose down

# Stop everything AND delete volumes (wipes database)
docker compose down -v

# Restart one service
docker compose restart app

# Rebuild one service image
docker compose build app
docker compose up -d --no-deps app  # restart just app without restarting dependencies
```

---

## Postgres Service Patterns

Standard Postgres configuration for this stack:

```yaml
postgres:
  image: postgres:16-alpine
  environment:
    POSTGRES_USER: ${POSTGRES_USER:-postgres}
    POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-postgres}
    POSTGRES_DB: ${POSTGRES_DB:-app}
  ports:
    - "5432:5432"          # expose to host for native mode and tools like psql/TablePlus
  volumes:
    - postgres_data:/var/lib/postgresql/data
  healthcheck:
    test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-postgres}"]
    interval: 5s
    timeout: 5s
    retries: 5
```

**To connect to Postgres directly from the host** (e.g., with psql or TablePlus):
- Host: `localhost`
- Port: `5432`
- User/pass/db from your `.env` or secrets

**To run Prisma commands against the local Docker DB** (from host, in local native mode):
```bash
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/app npx prisma studio
npx prisma migrate dev
```

---

## App Service Patterns

```yaml
app:
  build:
    context: .
    dockerfile: docker/Dockerfile.app
  environment:
    NODE_ENV: development
    DATABASE_URL: postgresql://postgres:postgres@postgres:5432/app
  volumes:
    - ./server:/app/server
    - /app/node_modules
  depends_on:
    postgres:
      condition: service_healthy
  ports:
    - "3000:3000"
```

**Hot reload** in Docker: The bind mount on `./server` allows code changes to reflect without
rebuilding. The app process inside needs to run with something like `nodemon` or `ts-node-dev`
to watch for changes. If hot reload isn't working, check:
1. Is the volume mount correct (source path relative to docker-compose.yml)?
2. Is the container's watch process (nodemon/ts-node-dev) actually watching the mounted path?
3. On Mac/Windows: file system events sometimes don't propagate into containers — use polling:
   `nodemon --legacy-watch` or set `CHOKIDAR_USEPOLLING=true`

---

## Swarm vs Compose

- **Development**: Docker Compose (`docker compose up`)
- **Production**: Docker Swarm (`docker stack deploy`)

Swarm differences relevant to debugging:
- Secrets: Docker Swarm secrets (`docker secret create`) rather than SOPS-decrypted files
- No bind mounts in production — images must be fully built
- Caddy configured via deploy labels on services rather than a Caddyfile
- Services can have replicas and rolling updates

Swarm commands:
```bash
docker stack deploy -c docker-stack.yml myapp
docker stack services myapp
docker stack ps myapp
docker service logs myapp_app
```
