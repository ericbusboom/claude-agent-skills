# Docker Installation Guide

This guide covers installing Docker on Mac, Linux, and Windows. Always ask the user what OS
they're on before giving specific instructions.

---

## Choosing: Docker Desktop vs OrbStack

Two main options for Mac and Linux users:

| | Docker Desktop | OrbStack |
|---|---|---|
| Mac support | Yes | Yes (recommended) |
| Linux support | Yes | Yes |
| Windows support | Yes | No |
| Resource usage | Higher | Lower |
| Speed | Standard | Faster |
| VM management | Docker VM only | Full Linux VM capabilities |
| Price | Free for personal/small biz | Free for individuals |
| License concern | Requires paid plan for large orgs | More permissive |

**Recommendation**: OrbStack for Mac/Linux. Docker Desktop for Windows (only real option).

---

## Mac Installation

### Option A: OrbStack (Recommended)

Official docs: https://orbstack.dev/download

**Quick install:**
```bash
brew install orbstack
```
Or download the `.dmg` from https://orbstack.dev/download

After install, OrbStack runs as a menu bar app. It provides a full Docker-compatible environment —
all `docker` and `docker compose` commands work identically.

**Verify:**
```bash
docker info
docker compose version
```

### Option B: Docker Desktop

Official docs: https://docs.docker.com/desktop/install/mac-install/

Download from https://www.docker.com/products/docker-desktop/

- Choose Apple Silicon (M1/M2/M3) or Intel based on your Mac
- Install the `.dmg`, drag to Applications
- Launch Docker Desktop from Applications
- Wait for the whale icon in the menu bar to show "Docker Desktop is running"

**Verify:**
```bash
docker info
```

---

## Linux Installation

### Option A: OrbStack (Recommended for desktop Linux)

Official docs: https://orbstack.dev/download

```bash
curl -SL https://orbstack.dev/install.sh | sh
```

Or via the docs for manual install options.

Note: OrbStack on Linux is newer than the Mac version — check the docs for supported distros.

### Option B: Docker Engine (Standard, no GUI needed)

This is the right choice for servers or headless Linux. Official install docs:
https://docs.docker.com/engine/install/

**Ubuntu/Debian:**
```bash
# Remove old versions
sudo apt-get remove docker docker-engine docker.io containerd runc

# Install using the convenience script (easiest)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add your user to docker group (so you don't need sudo)
sudo usermod -aG docker $USER
newgrp docker
```

**Then install Docker Compose plugin:**
```bash
sudo apt-get install docker-compose-plugin
```

**Fedora/RHEL:**
Follow https://docs.docker.com/engine/install/fedora/ or https://docs.docker.com/engine/install/rhel/

**Verify:**
```bash
docker info
docker compose version
```

**Common gotcha on Linux**: After adding yourself to the `docker` group, you need to log out and
back in (or run `newgrp docker`) for the group change to take effect. Otherwise you'll get
"permission denied" when running docker commands without sudo.

---

## Windows Installation

### Docker Desktop with WSL2 (Only mainstream option)

Official docs: https://docs.docker.com/desktop/install/windows-install/

**Prerequisites:**
- Windows 10 version 2004+ or Windows 11
- WSL2 enabled (Docker Desktop will offer to install it)
- Virtualization enabled in BIOS (usually already on)

**Steps:**
1. Download Docker Desktop installer from https://www.docker.com/products/docker-desktop/
2. Run the installer — accept defaults, enable WSL2 integration when prompted
3. Restart your computer
4. Launch Docker Desktop from Start menu
5. Wait for it to fully start (the whale icon in the system tray)

**Verify (in PowerShell or WSL terminal):**
```bash
docker info
docker compose version
```

**WSL2 integration note**: For the best experience with this project, use the WSL2 terminal (Ubuntu
or similar) rather than PowerShell for running `npm run dev` and docker commands. The project's
shell scripts are written for bash.

---

## Post-Install: Verifying the Setup Works for This Project

After installing Docker, verify the full stack can run:

```bash
# Clone the repo if not done
git clone https://github.com/League-Examples/docker-node-template.git
cd docker-node-template

# Run install script (handles dependencies + secrets)
./scripts/install.sh

# Start in local native mode (DB in Docker, app native)
npm run dev

# Or start in full Docker mode
npm run dev:docker
```

If `docker compose ps` shows services, you're good.

---

## Common Post-Install Issues

**"docker: command not found" after install**
- OrbStack/Docker Desktop: make sure the app is running (menu bar icon)
- Linux: check PATH includes `/usr/local/bin` or wherever docker was installed

**"Got permission denied while trying to connect to Docker daemon"** (Linux)
- Run `sudo usermod -aG docker $USER` then log out and back in

**Docker Desktop starts but compose fails**
- Check Docker Desktop Settings → Resources → Memory is at least 4GB for this stack

**OrbStack "not running" errors**
- Click the OrbStack menu bar icon → Start
