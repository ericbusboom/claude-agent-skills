# Caddy Reverse Proxy Configuration

Caddy handles reverse proxying and automatic HTTPS for the League Node template.
This document covers how Caddy is configured, how SSL/ACME works, and how to debug it.

Official Caddy docs: https://caddyserver.com/docs/

---

## What Caddy Does in This Stack

1. **Reverse proxy**: Routes incoming HTTP/HTTPS traffic to the correct internal service (app, client)
2. **Automatic HTTPS**: Obtains and renews TLS certificates via ACME (Let's Encrypt or ZeroSSL)
3. **Zero-config SSL**: Given a domain name, Caddy handles cert issuance with no manual steps

---

## Configuration Approaches

Two ways Caddy gets configured in this stack:

### 1. Caddyfile (Docker Compose / development)

A `Caddyfile` in the `docker/` directory defines routes explicitly:

```
# Basic example: proxy all traffic to the app
yourdomain.com {
    reverse_proxy app:3000
}

# With separate frontend and API routing
yourdomain.com {
    handle /api/* {
        reverse_proxy app:3000
    }
    handle {
        reverse_proxy client:5173
    }
}

# Localhost dev (self-signed cert)
localhost {
    reverse_proxy app:3000
}
```

The Caddyfile is mounted into the Caddy container:
```yaml
caddy:
  image: caddy:latest
  volumes:
    - ./docker/Caddyfile:/etc/caddy/Caddyfile
    - caddy_data:/data          # cert storage — must be a named volume to persist
    - caddy_config:/config
  ports:
    - "80:80"
    - "443:443"
```

**Important**: `caddy_data` must be a named volume (not a bind mount) so certificates persist
across container restarts. If certs keep regenerating or you hit Let's Encrypt rate limits,
a missing persistent volume is a likely cause.

### 2. Docker Labels (Docker Swarm / production)

In Swarm mode, Caddy picks up routing configuration from Docker labels on services:

```yaml
services:
  app:
    image: myapp:latest
    deploy:
      labels:
        caddy: yourdomain.com
        caddy.reverse_proxy: "{{upstreams 3000}}"
```

This requires the `caddy-docker-proxy` plugin: https://github.com/lucaslorentz/caddy-docker-proxy

The Caddy container watches Docker events and automatically updates its config when services
with `caddy.*` labels start or stop.

---

## How ACME / Automatic HTTPS Works

Caddy uses the ACME protocol to get TLS certificates from Let's Encrypt (default) or ZeroSSL.

**Requirements for cert issuance:**
1. A public domain name pointing to the server's IP
2. Ports 80 and 443 open and reachable from the internet
3. Caddy running and able to respond to ACME HTTP-01 or TLS-ALPN-01 challenges

**Caddy does this automatically** — no certbot, no cron jobs, no manual renewal. Just give it
a domain and it handles everything.

**What happens on first start with a new domain:**
1. Caddy sees the domain in its config
2. Makes an HTTP-01 challenge request to Let's Encrypt
3. Let's Encrypt verifies the domain by hitting `http://yourdomain.com/.well-known/acme-challenge/...`
4. Caddy proves ownership, receives cert
5. HTTPS starts working
6. Caddy auto-renews ~30 days before expiry

**ZeroSSL vs Let's Encrypt:**
Caddy 2.x uses ZeroSSL as default in some versions. Both work. If you want to force Let's Encrypt:
```
{
    acme_ca https://acme-v02.api.letsencrypt.org/directory
}

yourdomain.com {
    reverse_proxy app:3000
}
```

---

## Development on Localhost

For local dev, Caddy uses a **locally-trusted certificate** (not a real ACME cert). Caddy's
local CA issues it. Your browser will warn about it unless you install Caddy's root CA:

```bash
caddy trust   # installs the local CA certificate (run inside the Caddy container or with Caddy installed locally)
```

Or, in the Docker Compose setup:
```bash
docker compose exec caddy caddy trust
```

Then restart your browser. After this, `https://localhost` will show a valid cert.

Alternatively, just click through the browser warning in dev — it's safe for local use.

---

## Common Caddy Issues and Fixes

### SSL cert not issuing

**Symptom**: Browser shows "connection refused" or cert error on your domain.

**Check**:
```bash
docker compose logs caddy
```

Look for ACME errors. Common causes:
- Port 80/443 not open in firewall or cloud security group
- Domain DNS not pointing to the server yet (propagation can take minutes to hours)
- Let's Encrypt rate limit hit (5 certs per domain per week for duplicates)
- Caddy can't reach the internet (check your server's outbound connectivity)

**Rate limit workaround**: Use Let's Encrypt staging for testing:
```
{
    acme_ca https://acme-staging-v02.api.letsencrypt.org/directory
}
```
Staging certs aren't trusted by browsers but won't hit rate limits.

### "bind: address already in use" on port 80 or 443

Something else is using those ports. Check:
```bash
sudo lsof -i :80
sudo lsof -i :443
```

Common culprits: nginx, apache2, another Caddy instance, or a previous container that didn't
clean up properly.

### Caddy starts but traffic doesn't route

**Symptom**: 502 Bad Gateway or Caddy serves but app returns errors.

**Check**:
1. Is the upstream service running? `docker compose ps`
2. Is Caddy using the right service name? In Docker Compose, use the service name (`app`, not `localhost`)
3. Is the port correct? The app listens on 3000 — `reverse_proxy app:3000`

### Hot reload not working through Caddy

Vite's HMR (Hot Module Replacement) uses WebSockets. Caddy needs to pass WebSocket upgrades:
```
client.yourdomain.com {
    reverse_proxy client:5173 {
        header_up Host {upstream_hostport}
    }
}
```

Or more explicitly handle WebSocket upgrades. If HMR connects but then disconnects,
this is likely the issue.

### Caddy config validation

Before restarting Caddy with a new config, validate it:
```bash
docker compose exec caddy caddy validate --config /etc/caddy/Caddyfile
```

---

## Caddy in Docker Swarm (Production)

Using `caddy-docker-proxy`:

**Deploy Caddy as a Swarm service:**
```yaml
version: '3.8'
services:
  caddy:
    image: lucaslorentz/caddy-docker-proxy:latest
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock:ro
      - caddy_data:/data
    networks:
      - caddy
    deploy:
      placement:
        constraints:
          - node.role == manager

  app:
    image: myapp:latest
    networks:
      - caddy
    deploy:
      labels:
        caddy: yourdomain.com
        caddy.reverse_proxy: "{{upstreams 3000}}"

networks:
  caddy:
    external: true

volumes:
  caddy_data:
    external: true
```

Create the network and volume before deploying:
```bash
docker network create --driver=overlay caddy
docker volume create caddy_data
```

---

## Useful Caddy Resources

- Caddy Docs: https://caddyserver.com/docs/
- Caddyfile Reference: https://caddyserver.com/docs/caddyfile
- caddy-docker-proxy (Swarm labels): https://github.com/lucaslorentz/caddy-docker-proxy
- Caddy Community Forum: https://caddy.community/
- ACME / Let's Encrypt: https://letsencrypt.org/docs/
