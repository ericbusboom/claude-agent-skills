# Docker Debugging Playbook: League Node Template

Specific failure patterns with symptoms and fixes. Match the user's symptom to a section.

---

## Database Connection Refused

**Symptoms:**
- `Error: connect ECONNREFUSED 127.0.0.1:5432`
- `Error: connect ECONNREFUSED localhost:5432`
- Prisma: `Can't reach database server at localhost:5432`

**Diagnosis:**
```bash
docker compose ps           # is postgres container running?
docker compose logs postgres # any startup errors?
```

**Causes and fixes:**

1. **Wrong host in DATABASE_URL (most common in full Docker mode)**
   - In full Docker mode, the app container must use the Postgres *service name* (`postgres`), not `localhost`
   - Fix: `DATABASE_URL=postgresql://user:pass@postgres:5432/db`

2. **Postgres container not started**
   - Fix: `docker compose up -d postgres`

3. **Postgres still initializing**
   - On first run, Postgres takes a few seconds to be ready
   - Fix: Add health check + `depends_on: condition: service_healthy` in docker-compose.yml
   - Workaround: Wait 10 seconds and retry

4. **Port conflict — something else on 5432**
   - Check: `lsof -i :5432` (Mac/Linux) or `netstat -ano | findstr 5432` (Windows)
   - Fix: Stop the conflicting service, or change the host port mapping (e.g., `5433:5432`)
   - Update DATABASE_URL to use the new port if connecting from host

5. **Volume corruption after hard shutdown**
   - Fix: `docker compose down -v && docker compose up -d postgres`
   - Warning: This deletes all data in the local Postgres

---

## Container Won't Start / Keeps Restarting

**Symptoms:**
- `docker compose ps` shows "Restarting" status
- Container starts and immediately exits

**Diagnosis:**
```bash
docker compose logs app --tail=50    # look for the crash reason
docker compose ps                    # check status
```

**Common causes:**

1. **Missing environment variable**
   - The app crashes because a required env var is undefined
   - Fix: Check that secrets decrypted correctly, that `.env` file exists, that `entrypoint.sh` ran
   - Debug: `docker compose run --rm app env` to see what env vars are available

2. **Prisma migration failed on startup**
   - Symptoms: `Error: P1001` or `Error: migrate deploy` in logs
   - Causes: DB not ready, wrong DATABASE_URL, migration file error
   - Fix: Ensure postgres is healthy first; check DATABASE_URL; run migrations manually:
     ```bash
     docker compose exec app npx prisma migrate deploy
     ```

3. **Build error in application**
   - TypeScript compile error, missing dependency
   - Fix: Check `docker compose logs app` for the specific error

4. **Port already in use**
   - `listen EADDRINUSE: address already in use :::3000`
   - Fix: Find what's using port 3000: `lsof -i :3000`
   - Stop that process or change the compose port mapping

5. **Out of memory**
   - Container hit memory limit
   - Check: `docker stats` (live) or `docker inspect <container_id>` for OOMKilled
   - Fix: Increase Docker's memory in Docker Desktop Settings → Resources, or reduce the app's memory usage

---

## Secrets / Environment Variables Not Loading

**Symptoms:**
- App starts but features fail because env vars are missing
- `undefined` for `process.env.DATABASE_URL` or similar

**Diagnosis:**
```bash
# Check what env vars the running app sees
docker compose exec app env

# Check if entrypoint ran
docker compose logs app | grep -i "entrypoint\|secret\|decrypt"
```

**Causes and fixes:**

1. **SOPS/age key not installed**
   - The `install.sh` script handles this. If it didn't run: `./scripts/install.sh`
   - Check that the age key file exists (location varies — check install.sh for path)

2. **`.env` file not decrypted**
   - The `secrets/` directory contains SOPS-encrypted files
   - After `install.sh`, there should be a decrypted version (e.g., `.env.decrypted` or `.env`)
   - If missing, re-run `./scripts/install.sh` or manually decrypt: `sops -d secrets/.env.enc > secrets/.env`

3. **`env_file` path wrong in docker-compose.yml**
   - Verify the path matches the actual decrypted file location

4. **Wrong environment / wrong secrets file**
   - Development vs production secrets are different
   - Make sure you're loading the right file for your environment

---

## Hot Reload Not Working

**Symptoms:**
- Code changes don't reflect in the running app
- Have to manually restart containers to see changes

**Vite client (frontend):**
```bash
# Check if Vite HMR websocket is connecting
# Open browser devtools → Network → filter WS
# Should see a websocket connection to localhost or your domain
```

Common causes:
1. **Volume not mounted** — code changes on the host aren't reaching the container
   - Check docker-compose.yml: `./client:/app/client` bind mount must be present
2. **Chokidar polling needed** — file events don't propagate on Mac/Windows
   - In Vite config (`vite.config.ts`): `server: { watch: { usePolling: true } }`
3. **WebSocket not proxied through Caddy** — see caddy-config.md
4. **HMR port conflict** — Vite uses port 24678 for HMR by default; check it's not blocked

**Node app backend (nodemon/ts-node-dev):**
1. **Volume not mounted** — same as above, `./server:/app/server` must be in compose
2. **node_modules bind mount issue** — anonymous volume `/app/node_modules` must be present
3. **Watch command not running** — verify the container's CMD uses nodemon, not just `node`

---

## Prisma Migration Failures

**Symptoms:**
- `Error: The migration ... failed to apply cleanly`
- `Error: P3009 migrate found failed migrations`
- `Error: There is 1 unapplied migration`

**Diagnosis:**
```bash
docker compose exec app npx prisma migrate status
```

**Fixes:**

1. **Pending migrations (non-destructive)**
   ```bash
   docker compose exec app npx prisma migrate deploy
   ```

2. **Failed migration in dev**
   ```bash
   # Reset database (DELETES ALL DATA)
   docker compose exec app npx prisma migrate reset
   ```

3. **Migration conflict / drift**
   - The database schema doesn't match the migration history
   - In dev: reset and reapply (`prisma migrate reset`)
   - In prod: this needs careful manual resolution — don't blindly reset

4. **Database not accepting connections during migration**
   - Prisma runs migrations on app startup via `entrypoint.sh`
   - If Postgres isn't ready yet, migrations fail
   - Fix: Ensure `depends_on: condition: service_healthy` in compose

---

## Permission Errors

**Symptoms:**
- `EACCES: permission denied`
- Files created in container not writable by host user
- Mounted files showing as wrong owner

**Causes:**
- Container runs as root (uid 0) by default; files it creates are owned by root on the host
- Or container runs as a specific uid that doesn't match host user

**Fixes:**
1. **For volume-mounted directories in dev**: usually benign — the container can read/write, and you can too
2. **For files created by container that need to be writable by host**:
   ```bash
   sudo chown -R $USER:$USER ./some-directory
   ```
3. **For production**: set explicit user in Dockerfile:
   ```dockerfile
   RUN addgroup -S appgroup && adduser -S appuser -G appgroup
   USER appuser
   ```

---

## "Image not found" / Build Failures

**Symptoms:**
- `Error: No such image`
- Build fails with dependency install errors

**Fixes:**

1. **Rebuild after Dockerfile changes**
   ```bash
   docker compose build app
   # or
   docker compose up -d --build app
   ```

2. **Node modules not installing in container**
   - The Dockerfile's `RUN npm install` or `RUN npm ci` failed
   - Check: `docker compose build app` and look at build output
   - Common cause: `package.json` has a dependency that fails to build (native modules, wrong platform)

3. **Wrong architecture (Apple Silicon)**
   - Some images or native modules don't have ARM64 builds
   - Force AMD64 in compose: `platform: linux/amd64` on the service
   - Note: This uses Rosetta emulation and is slower

4. **Stale build cache causing issues**
   ```bash
   docker compose build --no-cache app
   ```

---

## Digital Ocean Managed Postgres Connection Issues

**Symptoms:**
- `Error: SSL required`
- `Error: FATAL: password authentication failed`
- `Error: Connection refused` to DO host

**Fixes:**

1. **SSL required by Digital Ocean**
   - All DO managed databases require SSL
   - Fix: Add `?sslmode=require` to DATABASE_URL:
     ```
     DATABASE_URL=postgresql://user:pass@db-host:25060/dbname?sslmode=require
     ```

2. **IP not in DO allowlist**
   - DO managed databases have a trusted sources allowlist
   - Fix: Add your server's IP (or `0.0.0.0/0` for all IPs — less secure) in DO console
   - Dashboard: Databases → your DB → Trusted Sources

3. **Wrong port**
   - DO Postgres uses port `25060` (not the standard `5432`)
   - Check your DATABASE_URL port

4. **Connection pool exhausted**
   - DO connection limits are lower than self-hosted
   - Fix: Use PgBouncer (available in DO dashboard) or reduce Prisma's connection pool size:
     ```
     DATABASE_URL=...?connection_limit=5
     ```

---

## Network Connectivity Between Containers

**Symptoms:**
- Container A can't reach container B by service name
- `nslookup postgres` fails inside app container

**Diagnosis:**
```bash
# From inside the app container
docker compose exec app sh
ping postgres
nslookup postgres
curl http://client:5173
```

**Causes:**
1. **Services on different networks** — services only communicate if they share a Compose network
2. **Service name typo** — double-check the service name in docker-compose.yml
3. **Service not running** — `docker compose ps`

**Fix:**
Make sure all services that need to talk to each other are on the same network:
```yaml
services:
  app:
    networks:
      - backend
  postgres:
    networks:
      - backend

networks:
  backend:
```

Or use the default Compose network (happens automatically when you don't specify networks).

---

## Useful Debug Commands Reference

```bash
# Container status
docker compose ps

# All container logs
docker compose logs -f

# Specific service logs (last 100 lines)
docker compose logs --tail=100 app

# Get a shell inside a container
docker compose exec app sh
docker compose exec postgres sh

# Run a one-off command in a new container (doesn't interfere with running services)
docker compose run --rm app npx prisma migrate status

# Check resource usage (live)
docker stats

# Inspect a container's configuration
docker inspect $(docker compose ps -q app)

# List volumes
docker volume ls

# Remove all stopped containers, unused images, unused networks
docker system prune

# Remove everything including volumes (WARNING: deletes data)
docker system prune --volumes
```
