---
name: docker-expert
description: >
  Docker Expert for the League Examples docker-node-template stack. Use this skill whenever
  the user asks about Docker, containers, Docker Compose, Caddy proxy, PostgreSQL in Docker,
  environment setup, installation of Docker or OrbStack, container debugging, SSL/ACME issues,
  or anything related to running the League Node application locally or in production.
  Trigger for questions like "my container won't start", "how do I install Docker",
  "Caddy isn't working", "database connection refused", "how do I run this with Docker",
  "OrbStack vs Docker Desktop", or any Docker-related error message.
---

# Docker Expert: League Node Template

This skill covers the full Docker environment for the `docker-node-template` stack. When a user
brings a Docker problem, orient around two questions first:

1. **What mode are they running?** (See Run Modes below)
2. **What is the failure symptom?** (container won't start, can't connect to DB, SSL error, etc.)

Then read the appropriate reference file and guide them.

---

## The Stack at a Glance

| Layer | Technology |
|---|---|
| Backend | Express 4 + TypeScript, Node.js 20 LTS |
| Frontend | Vite + React + TypeScript |
| Database | PostgreSQL 16 Alpine via Prisma ORM |
| Reverse Proxy | Caddy (with automatic HTTPS / ACME) |
| Orchestration | Docker Compose (dev) / Docker Swarm (prod) |
| Secrets | SOPS + age (at rest); Docker secrets (runtime) |
| Remote DB | Digital Ocean Managed Postgres |

## Run Modes

Three distinct modes — make sure you know which one the user is in before debugging:

### 1. Local Native (`npm run dev`)
- **Database**: Postgres runs in Docker
- **App server + client**: Run natively on the host (no container)
- **When to use**: Fast iteration; no need to rebuild containers on code changes
- Common issues: Docker not running, port conflicts on 5432, `.env` not pointing to `localhost`

### 2. Full Docker (`npm run dev:docker`)
- **Everything** runs in Docker Compose: Postgres + Express server + Vite client + Caddy
- **When to use**: Testing the full containerized stack, closer to production
- Common issues: Volume mounts, hot reload not working, Caddy SSL on localhost

### 3. Hybrid / Remote DB
- App runs locally (native or Docker); database is a **Digital Ocean Managed Postgres** instance
- Connection via `DATABASE_URL` env var pointing to DO
- Common issues: SSL required by DO (`?sslmode=require`), IP allowlist on DO, secrets not decrypted

## Quick Diagnostic Flow

When a user reports a problem, run through this mentally:

```
1. Is Docker daemon running?  →  docker info
2. Are containers up?         →  docker compose ps
3. Are services healthy?      →  docker compose logs <service>
4. Can services reach each other? → docker compose exec <service> ping <other>
5. Is it a secrets/env issue? → check entrypoint.sh ran, docker compose exec app env
```

Useful one-liners to share with the user:

```bash
# Show all container status
docker compose ps

# Tail logs for all services
docker compose logs -f

# Tail logs for one service
docker compose logs -f app

# Check Caddy specifically
docker compose logs -f caddy

# Restart a single service without taking down others
docker compose restart app

# Full teardown and rebuild (nuclear option)
docker compose down -v && docker compose up --build
```

---

## Reference Files

Read the appropriate reference file based on what the user needs:

- **`references/installation.md`** — Installing Docker Desktop or OrbStack on Mac, Linux, Windows.
  Read this when the user doesn't have Docker yet or is choosing between options.

- **`references/compose-patterns.md`** — The specific docker-compose.yml structure for this stack,
  service definitions, volume patterns, health checks, and how the three run modes map to Compose
  configuration. Read this when debugging service startup, networking, or volume issues.

- **`references/caddy-config.md`** — Caddy reverse proxy setup, zero-conf HTTPS, ACME/Let's Encrypt,
  domain labels, and SSL debugging. Read this when Caddy isn't routing, SSL certs aren't issuing,
  or the user is configuring a new domain.

- **`references/debugging.md`** — Common failure patterns with specific symptoms and fixes: DB
  connection refused, container OOM kills, permission errors, port conflicts, Prisma migration
  failures, secrets not mounting, and hot-reload broken. Read this for most "something's broken"
  questions.

---

## Key Concepts to Keep in Mind

### Secrets flow
Secrets are encrypted with SOPS + age. On startup, `docker/entrypoint.sh` decrypts them into
environment variables. If the app can't find env vars, the secrets didn't decrypt — check that
the age key is present and `install.sh` completed successfully.

### Caddy and SSL
Caddy handles HTTPS automatically via ACME (Let's Encrypt or ZeroSSL). In development on
localhost, it uses a self-signed cert. In production, it needs a public domain pointing at the
server to obtain a real cert. Caddy is configured via labels on services in Docker Swarm, or via
a `Caddyfile` in Docker Compose dev.

### Database connection strings
- Local Docker Postgres: `postgresql://user:pass@localhost:5432/dbname`
- Full Docker (service-to-service): `postgresql://user:pass@postgres:5432/dbname` (use service name, not localhost)
- Digital Ocean: `postgresql://...@db-hostname:25060/dbname?sslmode=require`

A very common mistake: using `localhost` for the database when running in full Docker mode.
The app container can't reach Postgres via `localhost` — it must use the Compose service name (`postgres`).

### Prisma migrations
Migrations run via `npx prisma migrate dev` (development) or `npx prisma migrate deploy` (production).
In Docker, the `entrypoint.sh` typically runs `prisma migrate deploy` on startup. If migrations fail,
the app will crash — check `docker compose logs app` for Prisma errors.

---

## When the User Needs to Install Docker

Read `references/installation.md`. The short version:

- **Mac**: Recommend OrbStack over Docker Desktop — faster, lower resource use, better VM management
- **Linux**: Docker Engine (not Desktop) is the standard; OrbStack also works well
- **Windows**: Docker Desktop with WSL2 backend is the primary option; OrbStack doesn't support Windows

Always ask what OS they're on before giving install instructions.
